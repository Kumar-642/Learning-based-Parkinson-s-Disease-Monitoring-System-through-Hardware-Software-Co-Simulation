// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
// Tool Version Limit: 2023.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XPARKINSON_PREDICT_H
#define XPARKINSON_PREDICT_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xparkinson_predict_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_BaseAddress;
} XParkinson_predict_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XParkinson_predict;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XParkinson_predict_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XParkinson_predict_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XParkinson_predict_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XParkinson_predict_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XParkinson_predict_Initialize(XParkinson_predict *InstancePtr, u16 DeviceId);
XParkinson_predict_Config* XParkinson_predict_LookupConfig(u16 DeviceId);
int XParkinson_predict_CfgInitialize(XParkinson_predict *InstancePtr, XParkinson_predict_Config *ConfigPtr);
#else
int XParkinson_predict_Initialize(XParkinson_predict *InstancePtr, const char* InstanceName);
int XParkinson_predict_Release(XParkinson_predict *InstancePtr);
#endif

void XParkinson_predict_Start(XParkinson_predict *InstancePtr);
u32 XParkinson_predict_IsDone(XParkinson_predict *InstancePtr);
u32 XParkinson_predict_IsIdle(XParkinson_predict *InstancePtr);
u32 XParkinson_predict_IsReady(XParkinson_predict *InstancePtr);
void XParkinson_predict_EnableAutoRestart(XParkinson_predict *InstancePtr);
void XParkinson_predict_DisableAutoRestart(XParkinson_predict *InstancePtr);

void XParkinson_predict_Set_input_img(XParkinson_predict *InstancePtr, u64 Data);
u64 XParkinson_predict_Get_input_img(XParkinson_predict *InstancePtr);
void XParkinson_predict_Set_output_logits(XParkinson_predict *InstancePtr, u64 Data);
u64 XParkinson_predict_Get_output_logits(XParkinson_predict *InstancePtr);

void XParkinson_predict_InterruptGlobalEnable(XParkinson_predict *InstancePtr);
void XParkinson_predict_InterruptGlobalDisable(XParkinson_predict *InstancePtr);
void XParkinson_predict_InterruptEnable(XParkinson_predict *InstancePtr, u32 Mask);
void XParkinson_predict_InterruptDisable(XParkinson_predict *InstancePtr, u32 Mask);
void XParkinson_predict_InterruptClear(XParkinson_predict *InstancePtr, u32 Mask);
u32 XParkinson_predict_InterruptGetEnabled(XParkinson_predict *InstancePtr);
u32 XParkinson_predict_InterruptGetStatus(XParkinson_predict *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
