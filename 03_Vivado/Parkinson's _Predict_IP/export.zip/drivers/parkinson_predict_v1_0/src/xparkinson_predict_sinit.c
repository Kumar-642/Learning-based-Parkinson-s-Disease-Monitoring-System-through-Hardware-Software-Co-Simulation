// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
// Tool Version Limit: 2023.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xparkinson_predict.h"

extern XParkinson_predict_Config XParkinson_predict_ConfigTable[];

XParkinson_predict_Config *XParkinson_predict_LookupConfig(u16 DeviceId) {
	XParkinson_predict_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XPARKINSON_PREDICT_NUM_INSTANCES; Index++) {
		if (XParkinson_predict_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XParkinson_predict_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XParkinson_predict_Initialize(XParkinson_predict *InstancePtr, u16 DeviceId) {
	XParkinson_predict_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XParkinson_predict_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XParkinson_predict_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

