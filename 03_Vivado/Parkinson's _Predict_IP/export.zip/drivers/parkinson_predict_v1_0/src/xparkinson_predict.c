// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
// Tool Version Limit: 2023.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xparkinson_predict.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XParkinson_predict_CfgInitialize(XParkinson_predict *InstancePtr, XParkinson_predict_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XParkinson_predict_Start(XParkinson_predict *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XParkinson_predict_ReadReg(InstancePtr->Control_BaseAddress, XPARKINSON_PREDICT_CONTROL_ADDR_AP_CTRL) & 0x80;
    XParkinson_predict_WriteReg(InstancePtr->Control_BaseAddress, XPARKINSON_PREDICT_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XParkinson_predict_IsDone(XParkinson_predict *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XParkinson_predict_ReadReg(InstancePtr->Control_BaseAddress, XPARKINSON_PREDICT_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XParkinson_predict_IsIdle(XParkinson_predict *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XParkinson_predict_ReadReg(InstancePtr->Control_BaseAddress, XPARKINSON_PREDICT_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XParkinson_predict_IsReady(XParkinson_predict *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XParkinson_predict_ReadReg(InstancePtr->Control_BaseAddress, XPARKINSON_PREDICT_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XParkinson_predict_EnableAutoRestart(XParkinson_predict *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XParkinson_predict_WriteReg(InstancePtr->Control_BaseAddress, XPARKINSON_PREDICT_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XParkinson_predict_DisableAutoRestart(XParkinson_predict *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XParkinson_predict_WriteReg(InstancePtr->Control_BaseAddress, XPARKINSON_PREDICT_CONTROL_ADDR_AP_CTRL, 0);
}

void XParkinson_predict_Set_input_img(XParkinson_predict *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XParkinson_predict_WriteReg(InstancePtr->Control_BaseAddress, XPARKINSON_PREDICT_CONTROL_ADDR_INPUT_IMG_DATA, (u32)(Data));
    XParkinson_predict_WriteReg(InstancePtr->Control_BaseAddress, XPARKINSON_PREDICT_CONTROL_ADDR_INPUT_IMG_DATA + 4, (u32)(Data >> 32));
}

u64 XParkinson_predict_Get_input_img(XParkinson_predict *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XParkinson_predict_ReadReg(InstancePtr->Control_BaseAddress, XPARKINSON_PREDICT_CONTROL_ADDR_INPUT_IMG_DATA);
    Data += (u64)XParkinson_predict_ReadReg(InstancePtr->Control_BaseAddress, XPARKINSON_PREDICT_CONTROL_ADDR_INPUT_IMG_DATA + 4) << 32;
    return Data;
}

void XParkinson_predict_Set_output_logits(XParkinson_predict *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XParkinson_predict_WriteReg(InstancePtr->Control_BaseAddress, XPARKINSON_PREDICT_CONTROL_ADDR_OUTPUT_LOGITS_DATA, (u32)(Data));
    XParkinson_predict_WriteReg(InstancePtr->Control_BaseAddress, XPARKINSON_PREDICT_CONTROL_ADDR_OUTPUT_LOGITS_DATA + 4, (u32)(Data >> 32));
}

u64 XParkinson_predict_Get_output_logits(XParkinson_predict *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XParkinson_predict_ReadReg(InstancePtr->Control_BaseAddress, XPARKINSON_PREDICT_CONTROL_ADDR_OUTPUT_LOGITS_DATA);
    Data += (u64)XParkinson_predict_ReadReg(InstancePtr->Control_BaseAddress, XPARKINSON_PREDICT_CONTROL_ADDR_OUTPUT_LOGITS_DATA + 4) << 32;
    return Data;
}

void XParkinson_predict_InterruptGlobalEnable(XParkinson_predict *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XParkinson_predict_WriteReg(InstancePtr->Control_BaseAddress, XPARKINSON_PREDICT_CONTROL_ADDR_GIE, 1);
}

void XParkinson_predict_InterruptGlobalDisable(XParkinson_predict *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XParkinson_predict_WriteReg(InstancePtr->Control_BaseAddress, XPARKINSON_PREDICT_CONTROL_ADDR_GIE, 0);
}

void XParkinson_predict_InterruptEnable(XParkinson_predict *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XParkinson_predict_ReadReg(InstancePtr->Control_BaseAddress, XPARKINSON_PREDICT_CONTROL_ADDR_IER);
    XParkinson_predict_WriteReg(InstancePtr->Control_BaseAddress, XPARKINSON_PREDICT_CONTROL_ADDR_IER, Register | Mask);
}

void XParkinson_predict_InterruptDisable(XParkinson_predict *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XParkinson_predict_ReadReg(InstancePtr->Control_BaseAddress, XPARKINSON_PREDICT_CONTROL_ADDR_IER);
    XParkinson_predict_WriteReg(InstancePtr->Control_BaseAddress, XPARKINSON_PREDICT_CONTROL_ADDR_IER, Register & (~Mask));
}

void XParkinson_predict_InterruptClear(XParkinson_predict *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XParkinson_predict_WriteReg(InstancePtr->Control_BaseAddress, XPARKINSON_PREDICT_CONTROL_ADDR_ISR, Mask);
}

u32 XParkinson_predict_InterruptGetEnabled(XParkinson_predict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XParkinson_predict_ReadReg(InstancePtr->Control_BaseAddress, XPARKINSON_PREDICT_CONTROL_ADDR_IER);
}

u32 XParkinson_predict_InterruptGetStatus(XParkinson_predict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XParkinson_predict_ReadReg(InstancePtr->Control_BaseAddress, XPARKINSON_PREDICT_CONTROL_ADDR_ISR);
}

